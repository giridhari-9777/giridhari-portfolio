// ============================================================
// Footer year
// ============================================================
document.getElementById('year').textContent = new Date().getFullYear();

// ============================================================
// Signal strip — waveform built from the five reward-signal
// values used in the flagship research project (safety,
// hallucination, out-of-context, embedding, grounding), repeated
// across the width like a film-strip / reward-signal hybrid.
// ============================================================
(function drawSignal(){
  const path = document.getElementById('signalPath');
  if(!path) return;
  const values = [0.88, 0.82, 0.76, 0.80, 0.85]; // safety, hallucination, ooc, embedding, grounding
  const width = 1200, height = 40, mid = 20, amp = 15;
  const cycles = 6;
  let d = `M 0 ${mid}`;
  const totalPoints = cycles * values.length;
  const step = width / totalPoints;
  for(let i = 0; i <= totalPoints; i++){
    const v = values[i % values.length];
    const x = i * step;
    const y = mid - (v - 0.5) * amp * (i % 2 === 0 ? 1 : -0.6);
    d += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
  }
  path.setAttribute('d', d);
})();

// ============================================================
// Scroll reveal
// ============================================================
const revealEls = document.querySelectorAll('.reveal');
if('IntersectionObserver' in window){
  // Opt into the hidden state only once JS has confirmed it can also reveal it.
  revealEls.forEach(el => el.classList.add('pre'));
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('in');
        entry.target.classList.remove('pre');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  revealEls.forEach(el => io.observe(el));
}

// ============================================================
// Mobile nav
// ============================================================
const navToggle = document.getElementById('navToggle');
const mobileMenu = document.getElementById('mobileMenu');
if(navToggle && mobileMenu){
  navToggle.addEventListener('click', () => {
    mobileMenu.classList.toggle('open');
  });
  mobileMenu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => mobileMenu.classList.remove('open'));
  });
}
