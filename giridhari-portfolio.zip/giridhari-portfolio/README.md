# Giridhari Padhy — Portfolio Site

A static site (plain HTML/CSS/JS — no build step) built from your résumé, your
design portfolio, your YouTube channel and your LinkedIn.

## Files

```
index.html      → all page content
styles.css      → design system (colors, type, layout, animation)
script.js       → signal-strip animation, scroll reveals, mobile menu
assets/
  profile.jpg                    → your photo, cropped from the résumé PDF
  Giridhari_Padhy_Resume.pdf     → powers the "Résumé" download buttons
```

## Deploy to Vercel (no coding required)

**Option A — drag and drop (fastest)**
1. Go to https://vercel.com and sign in (GitHub, Google, or email).
2. Click **Add New… → Project**, then choose **"Deploy from folder"** /
   drag the whole `giridhari-portfolio` folder (this one) onto the page.
3. Leave all settings as default — Vercel auto-detects a static site.
4. Click **Deploy**. You'll get a live URL in under a minute
   (something like `giridhari-padhy.vercel.app`).

**Option B — via GitHub (better if you'll keep updating it)**
1. Create a new GitHub repository and upload these files to it
   (GitHub.com → "Add file" → "Upload files" works fine, no git needed).
2. In Vercel, click **Add New… → Project → Import Git Repository** and pick
   that repo.
3. Keep the default settings and click **Deploy**.
4. Every time you push a change to GitHub, Vercel redeploys automatically.

**Option C — Vercel CLI**
```bash
npm i -g vercel
cd giridhari-portfolio
vercel
```

## Custom domain

Once deployed, go to your project on vercel.com → **Settings → Domains** to
add a custom domain (e.g. `giridharipadhy.com`) if you buy one later. The
free `*.vercel.app` URL works immediately with no extra setup.

## Editing content later

Everything is in plain text inside `index.html` — open it in any text editor,
search for the text you want to change (e.g. your bio, a project
description, a link), edit it, and re-deploy (drag the folder in again, or
push to GitHub if you used Option B).

## A couple of notes

- Your passport number and full postal address from the résumé were left
  off the public page for safety (those aren't things you want indexed by
  Google). Everything else from your résumé — including the file itself —
  is on the site.
- Your references' personal phone numbers/emails weren't published on the
  page itself (that's usually not shared publicly without asking the person
  first) — your mentors are credited by name on each research project
  instead. They're still in the downloadable résumé PDF if someone needs to
  reach them directly.
